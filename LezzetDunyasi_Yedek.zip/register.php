<?php require_once 'includes/functions.php'; ?>
<!DOCTYPE html>
<html lang="tr">

<head>
    <meta charset="UTF-8">
    <title>Kayıt Ol - Lezzet Dünyası</title>
    <link rel="stylesheet" href="assets/style.css">
    <style>
        .login-card {
            max-width: 450px;
            margin: 50px auto;
            background: white;
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>

<body>
    <div class="login-card">
        <h2 style="text-align:center; margin-bottom:20px;">Aramıza Katılın</h2>
        <form action="register_action.php" method="POST">
            <div class="form-group">
                <label>Kullanıcı Adı</label>
                <input type="text" name="username" class="form-control" required>
            </div>
            <div class="form-group">
                <label>E-posta</label>
                <input type="email" name="email" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Şifre</label>
                <input type="password" name="password" class="form-control" required>
            </div>
            <div class="form-group">
                <label style="margin-bottom: 15px; display: block;">🌿 Alerjen Durumu <small style="color: #888;">(Varsa
                        seçiniz)</small></label>
                <div
                    style="background: linear-gradient(135deg, #fff5f7 0%, #ffe8ec 100%); padding: 15px; border-radius: 15px;">
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                        <label
                            style="display: flex; align-items: center; gap: 8px; cursor: pointer; padding: 8px; border-radius: 8px; background: white;">
                            <input type="checkbox" name="alerjen[]" value="gluten" style="accent-color: #c44569;">
                            <span>🌾 Gluten</span>
                        </label>
                        <label
                            style="display: flex; align-items: center; gap: 8px; cursor: pointer; padding: 8px; border-radius: 8px; background: white;">
                            <input type="checkbox" name="alerjen[]" value="sut" style="accent-color: #0369a1;">
                            <span>🥛 Süt</span>
                        </label>
                        <label
                            style="display: flex; align-items: center; gap: 8px; cursor: pointer; padding: 8px; border-radius: 8px; background: white;">
                            <input type="checkbox" name="alerjen[]" value="fistik" style="accent-color: #b45309;">
                            <span>🥜 Fıstık</span>
                        </label>
                        <label
                            style="display: flex; align-items: center; gap: 8px; cursor: pointer; padding: 8px; border-radius: 8px; background: white;">
                            <input type="checkbox" name="alerjen[]" value="yumurta" style="accent-color: #dc2626;">
                            <span>🥚 Yumurta</span>
                        </label>
                        <label
                            style="display: flex; align-items: center; gap: 8px; cursor: pointer; padding: 8px; border-radius: 8px; background: white;">
                            <input type="checkbox" name="alerjen[]" value="cikolata" style="accent-color: #059669;">
                            <span>🍫 Çikolata</span>
                        </label>
                    </div>
                </div>
            </div>
            <button type="submit" class="btn btn-secondary" style="width:100%">Kayıt Ol</button>
        </form>
        <div style="text-align:center; margin-top:15px;">
            <a href="index.php" style="color:var(--text-color);">Giriş Ekranına Dön</a>
        </div>
    </div>
</body>

</html>