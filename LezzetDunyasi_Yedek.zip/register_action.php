<?php
require_once 'includes/functions.php';
require_once 'includes/security.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // Rate limiting - kayıt spam koruması
    if (!checkRateLimit('register', 5, 300)) {
        logSecurityEvent('RATE_LIMIT_EXCEEDED', 'Registration attempt blocked');
        redirect('register.php?error=too_many_attempts');
    }

    $username = cleanInput($_POST['username']);
    $email = cleanInput($_POST['email']);
    $password = $_POST['password'];

    // Input validasyonu
    $errors = [];

    if (empty($username) || empty($email) || empty($password)) {
        redirect('register.php?error=empty_fields');
    }

    if (!validateUsername($username)) {
        redirect('register.php?error=invalid_username');
    }

    if (!validateEmail($email)) {
        redirect('register.php?error=invalid_email');
    }

    if (!validatePassword($password)) {
        redirect('register.php?error=weak_password');
    }

    // Şifreyi hashle
    $password_hash = password_hash($password, PASSWORD_DEFAULT);

    // Alerjen checkbox'larını virgülle birleştir
    $alerjenler = isset($_POST['alerjen']) ? implode(',', array_map('sanitizeInput', $_POST['alerjen'])) : '';

    try {
        // Kullanıcı adı veya email zaten var mı kontrol et
        $check = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
        $check->execute([$username, $email]);

        if ($check->fetch()) {
            redirect('register.php?error=user_exists');
        }

        $stmt = $pdo->prepare("INSERT INTO users (username, password, email, role, allergy_info) VALUES (?, ?, ?, 'customer', ?)");
        $stmt->execute([$username, $password_hash, $email, $alerjenler]);

        // Otomatik giriş yap
        $last_id = $pdo->lastInsertId();
        regenerateSession();
        $_SESSION['user_id'] = $last_id;
        $_SESSION['username'] = $username;
        $_SESSION['user_role'] = 'customer';
        $_SESSION['alerjenler'] = $alerjenler;

        // Hoşgeldin e-postası gönder
        require_once 'includes/email.php';
        sendWelcomeEmail($email, $username);

        logSecurityEvent('REGISTRATION_SUCCESS', "New user: {$username}");

        redirect('menu.php');
    } catch (PDOException $e) {
        logSecurityEvent('REGISTRATION_FAILED', "Error: " . $e->getMessage());
        redirect('register.php?error=registration_failed');
    }
}
?>